var chat_data = [
  
   {
    question : "<img src='img/Image_2.png'>",
    answer_type: "string", // buttons, no_answer
    buttons_arr: [
    ]
  },
  
  
  {
    question: "Ты онлайн?",
    answer_type: "string", // buttons, no_answer
    buttons_arr: [
    ]
  },
  {
    question: "Слава Богам",
    answer_type: "no_answer", // buttons, no_answer
    buttons_arr: [
    ]
  },
  {
    question: "Послушай, я не знаю кто ты, но только ты можешь спасти мне жизнь.",
    answer_type: "no_answer", // buttons, no_answer
    buttons_arr: [
    ]
  },
  
   {
    question: "Знаю это звучит странно, но так и есть. Пожалуйста, не отключайся. Это не шутка.",
    answer_type: "no_answer", // buttons
  },
   
   {
    question: "Из какого ты города?",
    answer_type: "string", // buttons
    buttons_arr: [
    ]
  },
   {
    question: "Черт. Значит он не врал.",
    answer_type: "buttons", // buttons
    buttons_arr: [ "Кто он?", "О чем ты вообще?"
    ]
  },
   {
    question: "Меня зовут ?",
    answer_type: "string", // buttons
    buttons_arr: [
    ]
    
  },
  
  
  
  
  
  
   // ...
];